# 논어한입 프로젝트

학생 대상 논어 읽기 웹사이트입니다. GitHub Pages로 바로 배포할 수 있게 `index.html` 하나로 구성되어 있습니다.

## 업로드 방법
1. GitHub에서 새 repository를 만듭니다.
2. 이 폴더 안의 `index.html` 파일을 repository 루트에 업로드합니다.
3. GitHub 저장소에서 **Settings → Pages**로 이동합니다.
4. **Deploy from a branch**를 선택합니다.
5. Branch를 **main**, 폴더를 **/(root)** 로 선택 후 저장합니다.
6. 잠시 뒤 다음 형식의 주소로 접속할 수 있습니다.

`https://사용자이름.github.io/저장소이름`

## 포함 기능
- 오늘의 논어 자동 변경
- 지난 30일 기록
- 주제별 정리
- 편별 보기
- 전체 구절 검색

## 파일 구성
- `index.html` : 메인 웹페이지
